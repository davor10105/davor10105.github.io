# Tokenizers

Tokenizers are fundamental tools in natural language processing (NLP) that break down text into smaller units, often words or subwords, called tokens. These tokens serve as the basic building blocks for various NLP tasks such as text classification, translation, and language modeling. This educational material will delve into the types, mechanisms, and applications of tokenizers, providing a thorough understanding of their role in NLP.

## What is Tokenization?

Tokenization is the process of converting a sequence of text into individual units called tokens. These tokens can be as small as characters or as large as words and phrases, depending on the specific task and the type of tokenizer used. These tokens are then encoded as integers that serve as keys for dictionary lookup inside the initial embedding layer of the model.

### Why is Tokenization Important?

1. **Simplicity:** Simplifies the input text into manageable chunks.
2. **Consistency:** Helps standardize the text data for machine learning models.
3. **Efficiency:** Reduces the complexity of text processing tasks.
4. **Flexibility:** Allows handling of various languages and text formats.

## Types of Tokenizers

### 1. Word Tokenizers

Word tokenizers split text into individual words. This approach is straightforward but can struggle with languages without clear word boundaries and with complex word formations.

#### Example:
- Input: `"Tokenization is essential."`
- Output: `["Tokenization", "is", "essential", "."]`

### 2. Character Tokenizers

Character tokenizers break text into individual characters. This can handle any text but results in a large number of tokens, making it computationally expensive.

#### Example:
- Input: `"NLP"`
- Output: `["N", "L", "P"]`

### 3. Subword Tokenizers

Subword tokenizers break words into smaller, meaningful units. These are particularly useful for handling rare and out-of-vocabulary words.

#### Common Subword Tokenizers:
- **Byte Pair Encoding (BPE):** Iteratively merges the most frequent pairs of bytes or characters.
- **WordPiece:** Similar to BPE, used extensively in models like BERT.
- **SentencePiece:** Treats text as a sequence of Unicode characters and learns subword units from raw sentences.

#### Example:
- Input: `"unhappiness"`
- Output: `["un", "##happiness"]`

### 4. Sentence Tokenizers

Sentence tokenizers divide text into sentences, useful for tasks that require sentence-level processing like translation and summarization.

#### Example:
- Input: `"Hello world. This is NLP."`
- Output: `["Hello world.", "This is NLP."]`

## Choosing the Right Tokenizer

The choice of tokenizer depends on the specific NLP task, the language being processed, and the model architecture. Key considerations include:

1. **Task Requirements:** Different tasks may benefit from different tokenization strategies. For instance, text generation tasks often use subword tokenizers to handle rare words effectively.
2. **Language:** The structure of the language being processed influences the choice. Languages with clear word boundaries may use word tokenizers, while agglutinative languages may benefit from subword tokenizers.
3. **Model Compatibility:** Some models, like BERT and GPT, have specific tokenizer requirements (e.g., WordPiece for BERT, Byte Pair Encoding for GPT).

# Tokenizer Task
1. Implement word (splitting by whitespace), character and sentence (splitting by [.!?]) tokenizers. Make sure to lowercase the text first. The output should be a list of integers corresponding to the index of the token inside the vocabulary. Use each of your tokenizers on the following sequence:

```text
I must not fear. Fear is the mind-killer. Fear is the little-death that brings total obliteration. I will face my fear. I will permit it to pass over me and through me. And when it has gone past I will turn the inner eye to see its path. Where the fear has gone there will be nothing. Only I will remain.
```

2. Encode the same sequence using a pretrained WordPieces tokenizer from the `tokenizers` huggingface library. Start with the following code:

```python
from tokenizers import Tokenizer

tokenizer = Tokenizer.from_pretrained("bert-base-uncased")
```

[Next Page](9_llm_task.md)