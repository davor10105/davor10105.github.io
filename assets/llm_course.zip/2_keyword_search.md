### Keyword-Based Search

Keyword-based search is a fundamental technique in information retrieval (IR) that matches search queries with relevant documents based on the presence of specific keywords. This method has evolved over time, incorporating various algorithms and models to improve the accuracy and relevance of search results. This document explores some of the key concepts and techniques in keyword-based search, including Bag of Words (BoW), Term Frequency-Inverse Document Frequency (TF-IDF), and BM25, as well as the emergence of dense embeddings in modern search systems.

---

#### Bag of Words (BoW)

**Definition:**
Bag of Words (BoW) is one of the simplest and most straightforward models used in text analysis and information retrieval. It represents text data by treating each document as a collection (or "bag") of its individual words, disregarding grammar and word order but keeping multiplicity.

**How it Works:**
1. **Vocabulary Creation:** A unique list of all words present in the entire corpus (collection of documents) is created.
2. **Vector Representation:** Each document is represented as a vector where each dimension corresponds to a word from the vocabulary. The value in each dimension is the count (frequency) of the word in that document.

**Advantages:**
- Simple and easy to implement.
- Works well for basic text processing tasks.

**Disadvantages:**
- Ignores word order and context, leading to loss of meaning.
- Can result in very high-dimensional vectors, especially for large vocabularies.
- Treats all terms equally, without considering their importance.

---

#### Term Frequency-Inverse Document Frequency (TF-IDF)

**Definition:**
TF-IDF is a numerical statistic that reflects the importance of a word in a document relative to a collection of documents (corpus). It is widely used in information retrieval and text mining.

**Components:**
1. **Term Frequency (TF):** Measures how frequently a term appears in a document. It is calculated as:
   \[
   \text{TF}(t, d) = \frac{\text{Number of times term } t \text{ appears in document } d}{\text{Total number of terms in document } d}
   \]

2. **Inverse Document Frequency (IDF):** Measures how important a term is within the entire corpus. It is calculated as:
   \[
   \text{IDF}(t, D) = \log \left( \frac{\text{Total number of documents in the corpus } D}{\text{Number of documents containing term } t} \right)
   \]

**Calculation:**
\[
\text{TF-IDF}(t, d, D) = \text{TF}(t, d) \times \text{IDF}(t, D)
\]

**Advantages:**
- Provides a way to balance term frequency with document rarity, giving higher weight to terms that are common in a document but rare in the corpus.
- Helps in reducing the impact of frequently occurring common words (like "and", "the", etc.) that are not as important.

**Disadvantages:**
- Still ignores the semantics and word order.
- High-dimensional vectors, though typically less sparse than BoW.

---

#### BM25 (Best Match 25)

**Definition:**
BM25 is a probabilistic information retrieval model that builds on the TF-IDF framework but introduces several improvements to handle term frequency saturation and document length normalization.

**Formula:**
\[
\text{BM25}(t, d) = \sum_{t \in q} \text{IDF}(t) \cdot \frac{\text{TF}(t, d) \cdot (k_1 + 1)}{\text{TF}(t, d) + k_1 \cdot \left(1 - b + b \cdot \frac{|d|}{\text{avgdl}}\right)}
\]

Where:
- \( t \) is the term.
- \( d \) is the document.
- \( q \) is the query.
- \( k_1 \) and \( b \) are parameters that control term frequency saturation and document length normalization, respectively.
- \( |d| \) is the length of the document.
- \( \text{avgdl} \) is the average document length in the corpus.

**Advantages:**
- Incorporates term frequency saturation, meaning that the relevance score doesn't increase linearly with term frequency.
- Includes document length normalization, reducing the bias towards longer documents.

**Disadvantages:**
- Still based on keyword matching and may not capture semantic similarity.

---

### The Rise of Dense Embeddings

**Definition:**
Dense embeddings are continuous vector representations of words, phrases, or documents in a fixed-size, lower-dimensional space. These embeddings capture semantic meanings and relationships between words based on their context.

**Common Methods:**
- **Word2Vec:** A neural network-based model that generates word embeddings by predicting surrounding words (context) in a sentence.
- **GloVe (Global Vectors for Word Representation):** A model that captures global word co-occurrence statistics to generate embeddings.
- **BERT (Bidirectional Encoder Representations from Transformers):** A transformer-based model that generates contextualized embeddings by considering both left and right contexts in a sentence.

**Advantages:**
- **Semantic Understanding:** Dense embeddings capture semantic similarity, allowing for better understanding of the context and meaning of words.
- **Contextual Representation:** Models like BERT provide different embeddings for the same word depending on its context.
- **Lower Dimensionality:** Compared to sparse vectors from BoW or TF-IDF, dense embeddings are typically lower-dimensional and more compact.

---

### Conclusion

Keyword-based search methods like BoW, TF-IDF, and BM25 have been foundational in information retrieval, each offering unique advantages and limitations. However, the rise of dense embeddings marks a significant shift towards more semantic and context-aware search systems. By leveraging advanced models like Word2Vec, GloVe, and BERT, modern search engines can provide more accurate and relevant results, better understanding user queries and the content of documents. The two approaches are not, however, mutually exclusive, and often the best performing systems utilize both the dense embeddings and keyword-based search.

[Next Page](1_introduction.md)