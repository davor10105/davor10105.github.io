### Final Task (Embeddings)

In this module, your final task is to create a search engine that retrieves relevant articles about cryptocurrency.

1. Obtain the dataset containing articles related to cryptocurrency [here](https://www.kaggle.com/datasets/oliviervha/crypto-news).

2. Extract the `title` and `text` columns from __the first 100__ articles in the dataset. Combining the values of these columns will form the content used for embeddings.

3. Use the Amazon Titan model to embed the extracted text.

4. Store the resulting vectors into an OpenSearch index. Utilize LangChain to facilitate the indexing process. Include the `sentiment`, `source`, `subject` and `url` columns as metadata for each document.

5. Query the vector store for documents with `positive` sentiment using the following text: "bitcoin price".

[Next Page](6_llms.md)