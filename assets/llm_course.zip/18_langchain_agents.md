# Leveraging Tool Calling in Large Language Models (LLMs)

## Introduction
Large Language Models (LLMs) can now interact with external data sources through tool calling functionality. This powerful technique allows developers to build sophisticated applications that leverage LLMs to access, interact with, and manipulate external resources such as databases, files, and APIs.

Providers have been integrating native tool calling capabilities into their models. When an LLM provides an auto-completion to a prompt, it can return a list of tool invocations in addition to plain text. OpenAI first released this functionality with "function calling" which evolved into "tool calling" in November 2022. Since then, other providers have followed: Gemini (December), Mistral (February), Fireworks (March), Together (March), Groq (April), Cohere (April), and Anthropic (April).

However, these providers exposed slightly different interfaces, making interoperability a challenge. To address this, a standardized interface for tool calling has been introduced, making it easier to switch between providers.

The standard interface consists of:
1. `ChatModel.bind_tools()`: A method for attaching tool definitions to model calls.
2. `AIMessage.tool_calls`: An attribute on the `AIMessage` returned from the model for accessing the tool calls the model decided to make.
3. `create_tool_calling_agent()`: An agent constructor that works with any model implementing `bind_tools` and returns `tool_calls`.

Let's delve into each component.

## ChatModel.bind_tools(...)
To enable a model to use tools, we need to specify which tools are available by passing a list of tool definitions to the model, including a schema for the tool arguments. The exact format of the tool definitions varies by model provider. For example, OpenAI expects a dictionary with `name`, `description`, and `parameters` keys, while Anthropic expects `name`, `description`, and `input_schema`.

`ChatModel.bind_tools` provides a standard interface implemented by all tool-calling models, allowing you to specify available tools using raw tool definitions (dicts), Pydantic classes, LangChain tools, or arbitrary functions. This makes it easy to create generic tool definitions usable with any tool-calling model. Below, we implement a multiplication chatbot using LangChain tools:

```python
from langchain_aws import ChatBedrock
from langchain.tools import tool
from langchain_core.messages import HumanMessage, SystemMessage


@tool
def multiply(first_number: int, second_number: int):
    """Multiplies two numbers together"""
    return first_number * second_number


messages = [
    SystemMessage(content="You are a helpful calculator. Use the tools at your disposal to answer user's question."),
    HumanMessage(content="Hi, what is 5 * 7?"),
]

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
model = ChatBedrock(model_id=model_id).bind_tools([multiply])

response = model.invoke(messages)
response
```

```json
# AIMessage.tool_calls
[
    {
        'name': 'multiply',
        'args': {
            'first_number': 5,
            'second_number': 7
            },
        'id': 'toolu_bdrk_01GUwm7n6XdJChewDbuTT68T'
    }
]
```

The `AIMessage` will have a `tool_calls: List[ToolCall]` attribute populated if there are any tool invocations. As we can see, the LLM parsed both arguments correctly (5 and 7) and passed them to the tool.

## create_tool_calling_agent()
Looking at the example above we notice that we are not actually calling any tools yet, just obtaining the arguments for them using an LLM. To go a step further and automatically call the tool, return its result and let the LLM respond to the user using the result, we can utilize the `create_tool_calling_agent` functionality in LangChain.

Example:

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import ConfigurableField
from langchain_core.tools import tool
from langchain.agents import create_tool_calling_agent, AgentExecutor

@tool
def multiply(first_number: int, second_number: int):
    """Multiplies two numbers together"""
    return first_number * second_number

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful calculator. Use the tools at your disposal to answer user's question."), 
    ("human", "{input}"), 
    ("placeholder", "{agent_scratchpad}")
])

tools = [multiply]

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
model = ChatBedrock(model_id=model_id).bind_tools([multiply])

agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

response = agent_executor.invoke({"input": "Hi, what is 5 * 7?"})
```

```bash
> Entering new AgentExecutor chain...

Invoking: `multiply` with `{'first_number': 5, 'second_number': 7}`

35

So, 5 * 7 is equal to 35.
```

```plaintext
Output: So, 5 * 7 is equal to 35.
```

## with_structured_output
The `ChatModel.with_structured_output()` interface allows for getting structured outputs from a model. It is built on top of tool-calling for most models that support it. Use `with_structured_output` when you need a specific schema for information extraction tasks, while `bind_tools` is more general and flexible for agent applications. In this example, we define a Pydantic schema of a Joke and prompt the LLM to return an object corresponding to that schema:

```python
from langchain_core.pydantic_v1 import BaseModel, Field

class Joke(BaseModel):
    setup: str = Field(description="question to set up a joke")
    punchline: str = Field(description="answer to resolve the joke")

messages = [
    SystemMessage(content="You are a funny joke generator."),
    HumanMessage(content="Hi, tell me a joke about LangChain."),
]

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
model = ChatBedrock(model_id=model_id).with_structured_output(Joke)

response = model.invoke(messages)
response
```

```plaintext
Joke(setup='Why did the LangChain developer cross the road?', punchline='To get to the other side of the API!')
```

## Conclusion
The trend of introducing native tool calling capabilities into LLMs is expected to continue. The standardized tool calling interface aims to save time and effort for LangChain users and facilitate easier switching between different LLM providers.

# Task

1. Create an pipeline for parsing user movie reviews. Parse the following movie review:

```plaintext
"Inception" is an overly complex and confusing film that fails to engage audiences. The convoluted narrative and excessive exposition bog down the pacing, making it a frustrating viewing experience.
```

 into a Pydantic object containing the following keys:
 - movie_name - name of the movie
 - review_sentiment - sentiment of the review (can only be positive or negative)
  - lead_actor_name - name of the leading actor in the movie
  - director_name - name of the director of the movie

2. Since the original review does not contain all information needed for Pydantic object production, utilize the [Wikipedia API tool](https://python.langchain.com/v0.1/docs/modules/tools/#default-tools) in LangChain to dynamically obtain relevant information.

3. Swap out the word `Inception` in the review for the words `Rush Hour` and check if your pipeline retrieves correct information.