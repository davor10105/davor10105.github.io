## Introduction to Embedding Models
Embeddings are a form of learned representation for text, where words, phrases, sentences, or even entire documents are mapped to vectors of real numbers. These vectors capture semantic meanings and relationships between different pieces of text, allowing machines to understand and process human language more effectively.

### Why Use Embeddings?
Dimensionality Reduction: Raw text data is typically high-dimensional and sparse. Embeddings reduce this dimensionality, making it computationally efficient to handle.
Semantic Similarity: Embeddings capture the semantic similarity between words. For example, "king" and "queen" would have vectors that are closer to each other than to "apple".
Improved Model Performance: Models built on embeddings often perform better because embeddings provide a more meaningful representation of the data.
### Types of Embeddings
#### Word Embeddings
Word embeddings map individual words to vectors. Commonly used techniques include Word2Vec, GloVe, and FastText. These embeddings are pre-trained on large corpora and can be used in various NLP tasks.

#### Sentence Embeddings
Sentence embeddings extend the concept to entire sentences. Techniques like Universal Sentence Encoder and BERT provide embeddings for sentences, capturing the context and relationships between words within the sentence.

#### Document Embeddings
Document embeddings represent entire documents or paragraphs as vectors. These embeddings capture the overall topic and context of the document. Doc2Vec is a popular technique for creating document embeddings.

#### Popular Embedding Techniques
##### Word2Vec
Developed by Google, Word2Vec is a neural network-based approach to creating word embeddings. It comes in two variants:

- Continuous Bag of Words (CBOW): Predicts the target word from its surrounding context words.
- Skip-gram: Predicts the context words from the target word.

##### GloVe
GloVe (Global Vectors for Word Representation) is developed by Stanford. It combines the advantages of matrix factorization techniques and Word2Vec. It constructs a co-occurrence matrix and uses this matrix to find the word vectors.

##### FastText
FastText, developed by Facebook, extends Word2Vec by considering subword information. This approach is beneficial for morphologically rich languages and helps in dealing with out-of-vocabulary words by representing words as the sum of their character n-grams.

##### BERT
BERT (Bidirectional Encoder Representations from Transformers) is developed by Google. Unlike traditional models that read text sequentially, BERT reads entire sequences of words at once, allowing it to capture more context. It uses a transformer architecture and is pre-trained on a large corpus in an unsupervised manner.

##### GPT-Style Models
GPT (Generative Pre-trained Transformer) is an autoregressive model developed by OpenAI. It generates text by predicting the next word in a sequence, considering the previous context. GPT has been used for various tasks, from language translation to generating coherent, human-like text.

### Applications of Embedding Models
1. Text Classification: Embeddings are used to represent text data for classification tasks, such as spam detection, sentiment analysis, and topic categorization.
2. Machine Translation: Embeddings help in translating text from one language to another by capturing the semantic meaning of words and phrases.
3. Information Retrieval: Embeddings improve search engines and recommendation systems by providing better query-document matching.
4. Named Entity Recognition (NER): Embeddings assist in identifying and classifying entities (e.g., names, dates) in text.
5. Question Answering Systems: Embeddings help in understanding and retrieving the correct answers to user queries.

### Challenges and Considerations
1. Training Data: High-quality embeddings require large amounts of text data for training.
2. Computational Resources: Training embedding models, especially deep learning models like BERT and GPT, demands significant computational power.
3. Bias: Embeddings can inadvertently capture and propagate biases present in the training data, leading to biased outcomes in applications.
4. Interpretability: Understanding what embeddings capture and how they represent different linguistic properties is still an area of active research.

[Next Page](2_word2vec_numpy.md)