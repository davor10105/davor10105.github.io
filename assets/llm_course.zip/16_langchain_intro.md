## Intro to LangChain

In this chapter, we illustrate how to build a simple LLM application with LangChain. This application will translate text from English into another language. This is a great way to get started with LangChain - a lot of features can be built with just some prompting and an LLM call.

### Using Language Models

First up, let's learn how to use a language model by itself. LangChain supports many different language models that you can use interchangeably. In this chapter, we will be using the Anthropic Claude 3 Haiku model hosted on AWS Bedrock ([details](https://aws.amazon.com/bedrock/claude/?sec=bcomfai&pos=3)).

```python
from langchain_aws import ChatBedrock

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
model = ChatBedrock(model_id=model_id)
```

Let's first use the model directly. ChatModels are instances of LangChain "Runnables", which means they expose a standard interface for interacting with them. To just simply call the model, we can pass in a list of messages to the `.invoke` method.

```python
from langchain_core.messages import HumanMessage, SystemMessage

messages = [
    SystemMessage(content="Translate the following from English into Italian"),
    HumanMessage(content="hi!"),
]

model.invoke(messages)
```

```plaintext
AIMessage(content='ciao!', response_metadata={'token_usage': {'completion_tokens': 3, 'prompt_tokens': 20, 'total_tokens': 23}, 'model_name': 'gpt-4', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-fc5d7c88-9615-48ab-a3c7-425232b562c5-0')
```

---

### OutputParsers

Notice that the response from the model is an `AIMessage`. This contains a string response along with other metadata about the response. Oftentimes we may just want to work with the string response. We can parse out just this response by using a simple output parser.

We first import the simple output parser.

```python
from langchain_core.output_parsers import StrOutputParser

parser = StrOutputParser()
```

One way to use it is to use it by itself. For example, we could save the result of the language model call and then pass it to the parser.

```python
result = model.invoke(messages)
parser.invoke(result)
```

```plaintext
'Ciao!'
```

More commonly, we can "chain" the model with this output parser. This means this output parser will get called every time in this chain. This chain takes on the input type of the language model (string or list of messages) and returns the output type of the output parser (string).

We can easily create the chain using the `|` operator. The `|` operator is used in LangChain to combine two elements together.

```python
chain = model | parser
chain.invoke(messages)
```

```plaintext
'Ciao!'
```

---

### Prompt Templates

Right now we are passing a list of messages directly into the language model. Where does this list of messages come from? Usually, it is constructed from a combination of user input and application logic. This application logic usually takes the raw user input and transforms it into a list of messages ready to pass to the language model. Common transformations include adding a system message or formatting a template with the user input.

PromptTemplates are a concept in LangChain designed to assist with this transformation. They take in raw user input and return data (a prompt) that is ready to pass into a language model.

Let's create a `PromptTemplate` here. It will take in two user variables:

- `language`: The language to translate text into
- `text`: The text to translate

```python
from langchain_core.prompts import ChatPromptTemplate

# First, let's create a string that we will format to be the system message:
system_template = "Translate the following into {language}:"

# Next, we can create the PromptTemplate. This will be a combination of the system_template as well as a simpler template for where the put the text
prompt_template = ChatPromptTemplate.from_messages(
    [("system", system_template), ("user", "{text}")]
)

# The input to this prompt template is a dictionary. We can play around with this prompt template by itself to see what it does by itself
result = prompt_template.invoke({"language": "italian", "text": "hi"})

result
```

```plaintext
ChatPromptValue(messages=[SystemMessage(content='Translate the following into italian:'), HumanMessage(content='hi')])
```

We can see that it returns a `ChatPromptValue` that consists of two messages. If we want to access the messages directly we do:

```python
result.to_messages()
```

```plaintext
[SystemMessage(content='Translate the following into italian:'),
 HumanMessage(content='hi')]
```

---

### Chaining Together Components with LCEL

We can now combine this with the model and the output parser from above using the pipe (`|`) operator:

```python
chain = prompt_template | model | parser
chain.invoke({"language": "italian", "text": "hi"})
```

```plaintext
'ciao'
```

This is a simple example of using LangChain Expression Language (LCEL) to chain together LangChain modules. There are several benefits to this approach, including optimized streaming and tracing support.

# Task

1. Create a sentiment classification chain using the dataset from the previous task.
2. Use the implemented chain to classify three examples from each sentiment class.
3. Define a sentiment reversal chain to generate text with the opposite sentiment of the original. For example:
```text
(positive) "I watch this movie every single night, the main actor is dreamy and I am in love with the story." --> (negative) "I watch this movie every single night, but the main actor is overrated and the story is quite disappointing."
```