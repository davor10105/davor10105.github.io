## Retrieval Augmented Generation (RAG) with LangChain

We have now covered all of the components needed to create a Retrieval Augmented Generation (RAG) pipeline with LangChain. Let us implement such a pipeline.

### Concepts
A typical RAG application has two main components:
1. **Indexing**: Ingesting data from a source and indexing it (usually done offline).
2. **Retrieval and Generation**: Retrieving relevant data at runtime based on the user query and generating a response using the LLM.

### Indexing
#### 1. Load
We can utilize LangChain's DocumentLoaders to load data. In this case, we load this course's markdown representation from the local directory.

```python
from langchain_community.document_loaders import DirectoryLoader
from langchain_community.document_loaders import TextLoader

loader = DirectoryLoader(".", glob="*.md", loader_cls=TextLoader)
docs = loader.load()
print(len(docs[0].page_content))
print(docs[0].page_content[:500])
```

#### 2. Split
Our loaded documents get quite long. Some of them might be too long to fit in the context window of many models. Even for those models that could fit the full post in their context window, models can struggle to find information in very long inputs.

To handle this we’ll split the Document into chunks for embedding and vector storage. This should help us retrieve only the most relevant bits of the blog post at run time.

In this case we’ll split our documents into chunks of 1000 characters with 200 characters of overlap between chunks. The overlap helps mitigate the possibility of separating a statement from important context related to it. We use the RecursiveCharacterTextSplitter, which will recursively split the document using common separators like new lines until each chunk is the appropriate size. This is the recommended text splitter for generic text use cases.

We set `add_start_index=True` so that the character index at which each split Document starts within the initial Document is preserved as metadata attribute `start_index`.

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200, add_start_index=True)
all_splits = text_splitter.split_documents(docs)

print(len(all_splits))
print(len(all_splits[0].page_content))
print(all_splits[10].metadata)
```

```plaintext
retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 5})
retrieved_docs = retriever.invoke("What are embedding models?")
print(len(retrieved_docs))
print(retrieved_docs[0])
```

#### 3. Store
Now we need to index our text chunks so that we can search over them at runtime. As explained earlier, we will embed the contents of each document split and insert these embeddings into a vector database (or vector store). When we want to search over our splits, we take a text search query, embed it, and perform some sort of “similarity” search to identify the stored splits with the most similar embeddings to our query embedding.

We can embed and store all of our document splits in a single command using the Chroma vector store and BedrockEmbeddings model.

```python
from langchain_chroma import Chroma
from langchain_aws import BedrockEmbeddings

vectorstore = Chroma.from_documents(
    documents=all_splits, embedding=BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0")
)
```

### Retrieval and Generation
#### 1. Retrieve
Now let’s write the actual application logic. We want to create a simple application that takes a user question, searches for documents relevant to that question, passes the retrieved documents and initial question to a model, and returns an answer.

First we need to define our logic for searching over documents. LangChain defines a Retriever interface which wraps an index that can return relevant Documents given a string query.

The most common type of Retriever is the VectorStoreRetriever, which uses the similarity search capabilities of a vector store to facilitate retrieval. Any VectorStore can easily be turned into a Retriever with VectorStore.as_retriever():

```python
retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 5})
retrieved_docs = retriever.invoke("What are embedding models?")
print(len(retrieved_docs))
print(retrieved_docs[0])
```

```plaintext
5
page_content='## Introduction to Embedding Models
Embeddings are a form of learned representation for text, where words, phrases, sentences, or even entire documents are mapped to vectors of real numbers. These vectors capture semantic meanings and relationships between different pieces of text, allowing machines to understand and process human language more effectively.' metadata={'source': '1_introduction.md', 'start_index': 0}
```

#### 2. Generate
Create a chain that takes a question, retrieves relevant documents, constructs a prompt, passes it to a model, and returns an answer.
We’ll use a [prompt for RAG](https://smith.langchain.com/hub/rlm/rag-prompt) that is checked into the LangChain prompt hub.

```python
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_aws import ChatBedrock
from langchain import hub

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
llm = ChatBedrock(model_id=model_id)
prompt = hub.pull("rlm/rag-prompt")

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

rag_chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

response = rag_chain.invoke("What are embedding models?")
response
```

```plaintext
'Embedding models are a way of representing text data, such as words, phrases, sentences, or documents, as numerical vectors. These vectors capture the semantic meaning and relationships between different pieces of text, allowing machines to understand and process human language more effectively. Some common types of embedding models include word embeddings (e.g., Word2Vec, GloVe, FastText), sentence embeddings (e.g., Universal Sentence Encoder, BERT), and document embeddings (e.g., Doc2Vec). These embedding models can be used in various natural language processing tasks, such as text classification, machine translation, information retrieval, and question answering.'
```

### Built-in Chains
LangChain includes convenience functions `create_stuff_documents_chain` and `create_retrieval_chain` to streamline the creation of retrieval chains described above.

- `create_stuff_documents_chain` specifies how retrieved context is fed into a prompt and LLM. In this case, we will "stuff" the contents into the prompt -- i.e., we will include all retrieved context without any summarization or other processing. It largely implements our above rag_chain, with input keys context and input-- it generates an answer using retrieved context and query.

- `create_retrieval_chain` adds the retrieval step and propagates the retrieved context through the chain, providing it alongside the final answer. It has input key input, and includes input, context, and answer in its output.

We can also customize the system prompt, we just have to make sure to include the `{context}` placeholder to place the relevant chunks.

```python
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate

system_prompt = (
    "You are an assistant for question-answering tasks. "
    "Use the following pieces of retrieved context to answer "
    "the question. If you don't know the answer, say that you "
    "don't know. Use three sentences maximum and keep the "
    "answer concise."
    "\n\n"
    "{context}"
)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt),
        ("human", "{input}"),
    ]
)

question_answer_chain = create_stuff_documents_chain(llm, prompt)
rag_chain = create_retrieval_chain(retriever, question_answer_chain)

response = rag_chain.invoke({"input": "What are embedding models?"})
response["answer"]
```

```plaintext
'Embedding models are a type of learned representation that map words, phrases, sentences, or documents to vectors of real numbers. The key points about embedding models are:\n\n1. They capture semantic meanings and relationships between different pieces of text, allowing machines to understand and process human language more effectively.\n\n2. Embeddings are used in various NLP applications like text classification, machine translation, information retrieval, named entity recognition, and question answering systems.\n\n3. Embeddings provide dimensionality reduction, capture semantic similarity, and can improve the performance of NLP models.'
```

### Returning Sources
You can also list out all documents supplied to the `{context}` placeholder.

```python
for document in response["context"]:
    print(document)
    print()
```

```plaintext
page_content='## Introduction to Embedding Models
Embeddings are a form of learned representation for text...' metadata={'source': '1_introduction.md', 'start_index': 0}

page_content='### Applications of Embedding Models
1. Text Classification: ...' metadata={'source': '1_introduction.md', 'start_index': 3107}

page_content='### Why Use Embeddings?
Dimensionality Reduction: ...' metadata={'source': '1_introduction.md', 'start_index': 361}

page_content='### Commonly used pre-trained embeddings

Instead of training an embedding model ...' metadata={'source': '3_pretrained_embeddings.md', 'start_index': 0}

page_content='#### Sentence Embeddings
Sentence embeddings extend ...' metadata={'source': '1_introduction.md', 'start_index': 1126}
```

### Conclusion
By following this tutorial, you have learned how to build a Retrieval Augmented Generation (RAG) application using LangChain. This application can efficiently answer questions based on specific source information, showcasing the power of combining LLMs with additional data sources.

# Task

1. Use the OpenSearch vector store filled with crypto news from the previous chapter as a retriever.

2. Implement a RAG pipeline on this data and answer the question "Are there any news mentioning Bitcoin?"

3. Create a chatbot that interacts with the user via terminal and utilizes several tools:

    - RAG chain for retrieving relevant news information. The chatbot should use this tool to answer questions of type: "Are there any news about Bitcoin?"
    - Current price fetching tool that obtains the current price of a cryptocurrency using the CryptoCompare API. Register for a free API key [here](https://www.cryptocompare.com/cryptopian/api-keys) and use the following [library](https://pypi.org/project/cryptocompare/). When user asks about the current price of a cryptocurrency, the chabot should respond with the correct price.
    - Price converter that can convert one cryptocurrency into another, using the current price. This tool will be utilized for questions of type: "What is the price of Etherium in Bitcoin?"
    - Historical price fetching tool that retrieves a list of crypto price movements in the past week. The LLM can utilize this information to infer a currency's price trend. For example: Today's Bitcoin prices: [100, 95, 85, 80, 75, 70, 65] --> LLM --> The prices of Bitcoin seem to be dropping.

Example conversation with the chatbot:

```plaintext
User: Hi, are there any news about Bitcoin?

Assistant: According to the latest news, Bitcoin's price has been stalling around $42,000, and the cryptocurrency market as a whole has seen some downward pressure, with the global crypto market cap dropping by over 8% in 24 hours. However, some altcoins like ICP and BONK have experienced impressive gains recently. The lack of fresh news on ETF applications seems to be contributing to the market's sluggishness.

User: What is the current price of BTC?

Assistant: The current price of BTC is 52843.9 EUR.

User: Can you convert that to ETH?

Assistant: Of course, the price of BTC is 18.66 ETH.

User: What is the current price trend of BTC?

Assistant: Based on the given price list [58400.18, 58539.73, 57733.27, 55762.25, 52779.23, 52289.91, 53689.78], the trend can be assessed as follows:

58400.18 to 58539.73 (up)
58539.73 to 57733.27 (down)
57733.27 to 55762.25 (down)
55762.25 to 52779.23 (down)
52779.23 to 52289.91 (down)
52289.91 to 53689.78 (up)
Overall, the general trend appears to be downward, with a few intermittent increases.
```