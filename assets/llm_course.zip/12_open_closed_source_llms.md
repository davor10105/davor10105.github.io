# Open-Source and Closed-Source LLMs

Open-source and closed-source LLMs have distinct characteristics and benefits.

**Open Source LLMs:**
- Publicly accessible, fostering community-driven development.
- Anyone can inspect, modify, and distribute the software.
- Examples: GPT-2, GPT-Neo, BERT, ELECTRA, T5, Llama 3.

**Closed Source LLMs:**
- Proprietary, with restricted access to code and training data.
- Developed and maintained by specific organizations.
- Examples: GPT-3 & 4 by OpenAI, Anthropic Claude models, Google Gemini models

### Advantages of Open Source LLMs

**Community and Collaboration:**
- Thrives on global contributions for continuous improvement.
- Dedicated support channels for assistance and knowledge sharing.

**Transparency and Trust:**
- Accessible code allows thorough security audits and ethical oversight.
- Builds trust through open and ethical AI development.

### The Case for Closed Source LLMs

**Proprietary Advancements:**
- Access to specialized, cutting-edge solutions.
- Ideal for industries requiring bespoke AI tools.

**Support and Security:**
- Dedicated vendor support for companies lacking in-house AI expertise.
- Ensured data security through proprietary management.

## Evaluating the Impact of Both on Businesses

### Speed of Innovation & Customization

**Open Source LLMs:**
- Enables rapid customization and innovation.
- Ideal for businesses with technical expertise for model adaptation.

**Closed Source LLMs:**
- Offers advanced performance with less flexibility.
- Relies on vendor updates, potentially slowing innovation.

### Security

**Open Source LLMs:**
- Enhanced control over security when deployed on private clouds.
- Transparency allows thorough audits and community-driven security improvements.

**Closed Source LLMs:**
- Security managed by the vendor, ideal for companies without large IT departments.
- Compliance certifications simplify regulatory adherence.

At the time of writing this course, most performant LLMs are closed-source (by far).

![LLM Leaderboard](images/leaderboard.png)

[Next Page](11_langchain.md)