### Creating your own Word2Vec model

### Continuous Bag of Words (CBOW)
The CBOW model predicts the target word given its surrounding context words. It averages the context word vectors to predict the target word, focusing on capturing the context in which a word appears.

**Architecture:**
- **Input Layer:** Context words (e.g., surrounding words in a window).
- **Projection Layer:** Averaging the vectors of context words.
- **Output Layer:** Softmax layer predicting the target word.

**Advantages:**
- Efficient for smaller datasets.
- Captures the context of the target word effectively.

**Example:**
For the sentence "The quick brown fox jumps over the lazy dog," if we use a window size of 2, to predict the word "brown," the context words are ["The", "quick", "fox", "jumps"].

### Skip-Gram Model
The Skip-Gram model, in contrast to CBOW, predicts the context words given a target word. It focuses on generating word embeddings that can predict surrounding words, which often works better for larger datasets.

**Architecture:**
- **Input Layer:** Target word.
- **Projection Layer:** Linear transformation to the hidden layer.
- **Output Layer:** Softmax layer predicting the context words.

**Advantages:**
- More effective for larger datasets.
- Captures rare words and phrases better.

**Example:**
For the same sentence, to predict context words ["quick", "brown", "jumps", "over"] given the target word "fox," the model learns embeddings that can predict these context words.

![CBOW and Skip-Gram variants](images/cbow_skipgram.png)

### Training Word2Vec Models
Both CBOW and Skip-Gram models are trained using [stochastic gradient descent](https://en.wikipedia.org/wiki/Gradient_descent) and [backpropagation](https://en.wikipedia.org/wiki/Backpropagation). Key techniques used during training include:
- **Negative Sampling:** Simplifies the softmax layer, making training more efficient.
- **Hierarchical Softmax:** Speeds up computation for large vocabularies.

### Implementation with Libraries
Here’s a brief overview using Gensim:

**Installing Gensim:**
```bash
pip install gensim
```

**Training a Word2Vec Model:**
```python
from gensim.models import Word2Vec

# Sample corpus
sentences = [["the", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog"],
             ["I", "love", "machine", "learning"],
             ["word2vec", "is", "a", "great", "technique"]]

# Training the model
model = Word2Vec(sentences, vector_size=100, window=5, min_count=1, workers=4)

# Accessing word vectors
vector = model.wv['quick']
```

### Vector Similarity Functions
Once we train a vector-producing embedding model, we can utilize it to perform semantic search. For this, we need to define similarity functions that measure how similar or different two vectors are. Here, we cover some of the most commonly used similarity functions, including Cosine Similarity and Euclidean Distance.

---

### Cosine Similarity
Cosine Similarity measures the cosine of the angle between two vectors. It ranges from -1 to 1, where 1 means the vectors are identical, 0 means they are orthogonal (no similarity), and -1 means they are diametrically opposed.

**Mathematical Formula:**
\[ \text{Cosine Similarity} = \frac{\vec{A} \cdot \vec{B}}{\|\vec{A}\| \|\vec{B}\|} \]
where \( \vec{A} \cdot \vec{B} \) is the dot product of vectors A and B, and \( \|\vec{A}\| \) and \( \|\vec{B}\| \) are the magnitudes of vectors A and B, respectively.

**Python Implementation:**
```python
import numpy as np

def cosine_similarity(vec1, vec2):
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    return dot_product / (norm_vec1 * norm_vec2)

# Example
vec1 = np.array([1, 2, 3])
vec2 = np.array([4, 5, 6])
print("Cosine Similarity:", cosine_similarity(vec1, vec2))
```

### Euclidean Distance
Euclidean Distance measures the straight-line distance between two vectors in Euclidean space. It is a popular distance metric in various machine learning algorithms.

**Mathematical Formula:**
\[ \text{Euclidean Distance} = \sqrt{\sum_{i=1}^{n} (A_i - B_i)^2} \]
where \( A_i \) and \( B_i \) are the components of vectors A and B.

**Python Implementation:**
```python
import numpy as np

def euclidean_distance(vec1, vec2):
    return np.linalg.norm(vec1 - vec2)

# Example
vec1 = np.array([1, 2, 3])
vec2 = np.array([4, 5, 6])
print("Euclidean Distance:", euclidean_distance(vec1, vec2))
```

### Analyzing and Visualizing Embeddings
Visualizing word embeddings helps in understanding their properties. Techniques like PCA (Principal Component Analysis) and t-SNE (t-distributed Stochastic Neighbor Embedding) are commonly used for this purpose.

t-SNE, or t-Distributed Stochastic Neighbor Embedding, is a popular machine learning algorithm used for visualizing high-dimensional data. Developed by Laurens van der Maaten and Geoffrey Hinton, t-SNE excels at reducing the dimensionality of complex datasets while preserving the relationships between data points. This technique maps multi-dimensional data to two or three dimensions, making it easier to visualize and interpret patterns, clusters, and anomalies within the data. t-SNE achieves this by minimizing the divergence between probability distributions of points in the high-dimensional space and the low-dimensional space, ensuring that similar points remain close together and dissimilar points are pushed apart.

```bash
pip install scikit-learn
pip install matplotlib
```

**Example using t-SNE:**
```python
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# Get word vectors
words = list(model.wv.index_to_key)
word_vectors = model.wv[words]

# Reduce dimensions
tsne = TSNE(n_components=2, perplexity=10)
word_vectors_2d = tsne.fit_transform(word_vectors)

# Plotting
plt.figure(figsize=(14, 8))
plt.scatter(word_vectors_2d[:, 0], word_vectors_2d[:, 1])

for i, word in enumerate(words):
    plt.annotate(word, xy=(word_vectors_2d[i, 0], word_vectors_2d[i, 1]))

plt.show()
```

### Task

1. Train CBOW and Skip-Gram versions of Word2Vec model using `gensim` on the following dataset (using train examples): https://ai.stanford.edu/~amaas/data/sentiment/
2. Preprocess the data to remove punctuation, lowercase the text and split the data into words.
3. List top 10 most similar words to the word "love" using cosine similarity.
4. Calculate the cosine similarity between the following two sentences:
- "I love horror movies"
- "Romantic comedies are so boring"
5. Visualize the embeddings of the first 200 words in your vocabulary using tSNE. Try using different similarity functions.
6. Cluster the test examples from the dataset into two clusters using KMeans clustering and calculate the classification accuracy on the test set (positive and negative sentiment).

[Next Page](3_pretrained_embeddings.md)