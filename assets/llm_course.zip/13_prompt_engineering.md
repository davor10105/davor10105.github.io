# Prompt Engineering

Modern LLMs are often tuned to follow user instructions specified in prompts. Prompting is a crucial technique in leveraging the capabilities of LLMs, to perform a wide range of tasks. The effectiveness of these models heavily depends on how they are prompted, or how input queries and instructions are framed. By crafting precise and contextually appropriate prompts, users can guide LLMs to produce more accurate, relevant, and useful outputs. This approach allows non-expert users to tap into the sophisticated capabilities of LLMs without needing extensive technical knowledge, making it a versatile tool for various applications including content creation, coding assistance, educational support, and customer service. Understanding the principles of effective prompting is essential for maximizing the potential of these advanced AI models.

### Understanding and Configuring Parameters for Large Language Models (LLMs)

When working with Large Language Models (LLMs) via an API, you have the ability to configure several parameters to optimize the performance and output of your prompts. Adjusting these settings is crucial for improving the reliability and desirability of responses, and often involves a degree of experimentation. Below are some common settings you will encounter when using different LLM providers:

#### Temperature
- **Definition**: Controls the randomness of the model's output.
- **Low Temperature**: More deterministic results, as the model selects the highest probable next token. Suitable for tasks requiring factual and concise responses, such as fact-based question answering (QA).
- **High Temperature**: Increases randomness, leading to more diverse or creative outputs. Useful for tasks like poem generation or other creative endeavors.

#### Top P (Nucleus Sampling)
- **Definition**: A sampling technique that works with temperature to control the determinism of the model.
- **Low Top P**: Selects tokens that comprise the top-p probability mass, leading to more confident and factual responses.
- **High Top P**: Allows the model to consider a broader range of tokens, including less likely ones, resulting in more diverse outputs.
- **General Recommendation**: Adjust either the Temperature or Top P, but not both simultaneously.

#### Max Length
- **Definition**: Controls the number of tokens the model generates.
- **Usage**: Helps prevent overly long or irrelevant responses and manages costs by specifying a maximum length for the output.

#### Stop Sequences
- **Definition**: Specific strings that instruct the model to stop generating further tokens.
- **Usage**: Useful for controlling the length and structure of responses. For example, adding "11" as a stop sequence can limit a list to 10 items.

#### Frequency Penalty
- **Definition**: Applies a penalty to the next token based on how frequently it has appeared in the response and prompt.
- **High Frequency Penalty**: Reduces word repetition by penalizing tokens that appear more frequently.
- **Usage**: Helps create more varied responses.

#### Presence Penalty
- **Definition**: Applies a consistent penalty to repeated tokens, irrespective of their frequency.
- **High Presence Penalty**: Prevents the model from repeating phrases too often, encouraging diversity in the text.
- **Low Presence Penalty**: Keeps the model focused on the topic.
- **General Recommendation**: Adjust either the Frequency or Presence Penalty, but not both simultaneously.

### Key Takeaways
- **Experimentation**: Finding the right settings requires trial and error.
- **Version Variability**: Results may vary depending on the version of the LLM you use.

## Basic Prompting

You can achieve a lot with simple prompts. The quality of the output, however, depends on how much information you provide and how well you craft the prompt. A good prompt includes clear instructions, context, inputs, or examples to guide the model. The following examples are generated using Claude Haiku, but general practices described in the following sections can be applied to any modern LLM.

## Basic Prompt Example

**Prompt:**
The grass is

**Output:**
green.

## Using Chat LLMs

When using models like GPT, Claude or Gemini, you can structure your prompt with three roles: system, user, and assistant. The **system** sets the overall behavior, the **user** provides the prompt, and the **assistant** is the model's response. In these simple examples, we mostly use user messages for simplicity.

## Improving Prompts

You can observe from the prompt example above that the language model responds with a sequence of tokens that make sense given the context "The grass is". The output might be unexpected or far from the task you want to accomplish. In fact, this basic example highlights the necessity to provide more context or instructions on what specifically you want to achieve with the system. This is what prompt engineering is all about.

Let's try to improve it a bit:

**Improved Prompt:**
Complete the sentence:  
The grass is

**Improved Output:**
green in the spring and brown in the fall.

Is that better? Well, with the prompt above you are instructing the model to complete the sentence so the result looks a lot better as it follows exactly what you told it to do ("complete the sentence"). This approach of designing effective prompts to instruct the model to perform a desired task is what's referred to as **prompt engineering**.

