Streamlit is an open-source framework designed to simplify the process of building and deploying interactive web applications for data science and machine learning projects. It allows developers and data scientists to transform data scripts into shareable web apps with minimal effort. By using simple Python code, users can create highly customizable and visually appealing applications without requiring extensive knowledge of web development. Streamlit's user-friendly interface, real-time updates, and seamless integration with popular Python libraries make it an ideal tool for rapidly prototyping and sharing data-driven insights and machine learning models. Whether for exploratory data analysis, dashboard creation, or model deployment, Streamlit empowers users to communicate their findings and solutions effectively.

## Getting Started

Once installed, you can start by creating the following `app.py` file:

```python
import streamlit as st

st.write("Hello world")
```

And run it using:

```bash
streamlit run app.py
```

This will open your browser and display your app:

![alt text](images/app1.png)

This, of course, is not too interesting to look at. However, Streamlit enables easy embedding of different elements, such as graphs, visualizations or even chat. Let's start with a simple visualization of a pandas dataframe:

Update your `app.py`:

```python
import streamlit as st
import pandas as pd

st.write(pd.DataFrame({
    'first column': [1, 2, 3, 4],
    'second column': [10, 20, 30, 40]
}))
```

![alt text](images/app2.png)

To visualize a line chart:

```python
import streamlit as st
import numpy as np
import pandas as pd

chart_data = pd.DataFrame(np.random.randn(20, 3), columns=["a", "b", "c"])

st.line_chart(chart_data)
```

![alt text](images/app3.png)

There are many more displayable, input and accessory type components. You can read more [here](https://docs.streamlit.io/develop/api-reference).

# Task

1. Let us focus on our use-case - chatbots. We can implement a simple chat UI in Streamlit that utilizes LangChain for LLM communication using the following code snippet:


```python
from langchain.agents import ConversationalChatAgent, AgentExecutor
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain_aws import ChatBedrock

import streamlit as st

st.set_page_config(page_title="LangChain: Chat with search", page_icon="🪙")
st.title("🪙 Crypto Chatbot")

# configure message memory
msgs = StreamlitChatMessageHistory()
memory = ConversationBufferMemory(
    chat_memory=msgs, return_messages=True, memory_key="chat_history", output_key="output"
)
if len(msgs.messages) == 0 or st.sidebar.button("Reset chat history"):
    msgs.clear()

# display currently stored messages
avatars = {"human": "user", "ai": "assistant"}
for idx, msg in enumerate(msgs.messages):
    with st.chat_message(avatars[msg.type]):
        st.write(msg.content)

# get user input an generate the response
if prompt := st.chat_input(placeholder="What are the latest news on Bitcoin?"):
    st.chat_message("user").write(prompt)

    model_id = "anthropic.claude-3-haiku-20240307-v1:0"
    llm = ChatBedrock(model_id=model_id)
    
    # your agent goes here
    # agent = ...
    # tools = ...
    
    with st.chat_message("assistant"):
        response = agent.invoke(prompt)

        # display the response
        st.write(response["output"])
```

Update the code snippet with your agent's code from the previous task.