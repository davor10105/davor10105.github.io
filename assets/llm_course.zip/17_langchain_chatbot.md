# Creating a chatbot in LangChain

In this chapter, we will explore how to design and implement a simple LLM-powered chatbot. The chatbot we will create will be capable of maintaining a conversation and recalling previous interactions.

To begin, we will first start with the same model as in the last chapter.

```python
from langchain_aws import ChatBedrock

model_id = "anthropic.claude-3-haiku-20240307-v1:0"
model = ChatBedrock(model_id=model_id)
```

To invoke the model, you pass a list of messages to the `.invoke()` method:

```python
from langchain_core.messages import HumanMessage

model.invoke([HumanMessage(content="Hi! I'm Bob")])
```

Initially, the model does not retain state between interactions, which leads to a poor chatbot experience. For example, if you follow up with:

```python
model.invoke([HumanMessage(content="What's my name?")])
```

The model will not recall prior interactions. To enable statefulness, you must pass the entire conversation history to the model:

```python
from langchain_core.messages import AIMessage

model.invoke(
    [
        HumanMessage(content="Hi! I'm Bob"),
        AIMessage(content="Hello Bob! How can I assist you today?"),
        HumanMessage(content="What's my name?"),
    ]
)
```

### Message History

To create a stateful chatbot, we utilize a `Message History` class that maintains the conversation context. Begin by installing `langchain-community`, which provides the necessary integration for message history.

```bash
pip install langchain_community
```

Then, we can define a dictionary that maps `session_id` to a user's chat `ChatMessageHistory`.

```python
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

store = {}

def get_session_history(session_id: str) -> BaseChatMessageHistory:
    if session_id not in store:
        store[session_id] = ChatMessageHistory()
    return store[session_id]

with_message_history = RunnableWithMessageHistory(model, get_session_history)
```

Create a configuration for the session:

```python
config = {"configurable": {"session_id": "abc2"}}
response = with_message_history.invoke(
    [HumanMessage(content="Hi! I'm Bob")],
    config=config,
)
```

If you change the `session_id`, you can start a new conversation:

```python
config = {"configurable": {"session_id": "abc3"}}

response = with_message_history.invoke(
    [HumanMessage(content="What's my name?")],
    config=config,
)
```

You can switch back to the original conversation:

```python
config = {"configurable": {"session_id": "abc2"}}

response = with_message_history.invoke(
    [HumanMessage(content="What's my name?")],
    config=config,
)
```

### Prompt Templates

Similarly to the last chapter, you can also utilize `ChatPromptTemplate` to dinamically populate the input. Let's now make that a bit more complicated. First, let's add in a system message with some custom instructions (but still taking messages as input). Next, we'll add in more input besides just the messages.

First, let's add in a system message. To do this, we will create a ChatPromptTemplate. We will utilize MessagesPlaceholder to pass all the messages in.

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant. Answer all questions to the best of your ability.",
        ),
        MessagesPlaceholder(variable_name="messages"),
    ]
)

chain = prompt | model
```

Note that this slightly changes the input type - rather than pass in a list of messages, we are now passing in a dictionary with a `messages` key where that contains a list of messages.

```python
response = chain.invoke({"messages": [HumanMessage(content="hi! I'm bob")]})
```

We can now wrap this in the same Messages History object as before:

```python
with_message_history = RunnableWithMessageHistory(chain, get_session_history)

config = {"configurable": {"session_id": "abc5"}}

response = with_message_history.invoke(
    [HumanMessage(content="Hi! I'm Jim")],
    config=config,
)

response.content
```

```text
'Hello, Jim! How can I assist you today?'
```

```python
response = with_message_history.invoke(
    [HumanMessage(content="What's my name?")],
    config=config,
)

response.content
```

```text
'Your name is Jim.'
```

We can also include the language specification from before, we also have to specify the key to be saved in the memory, in this case `messages`:

```python
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant. Answer all questions to the best of your ability in {language}.",
        ),
        MessagesPlaceholder(variable_name="messages"),
    ]
)

chain = prompt | model
with_message_history = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="messages",
)
```

And invoke the chain by passing the `language` parameter:

```python
response = with_message_history.invoke(
    {"messages": [HumanMessage(content="hi! I'm bob")], "language": "Spanish"}
)

response.content
```

```text
'¡Hola, Bob! ¿En qué puedo ayudarte hoy?'
```

We can check that the memory is working:

```python
response = with_message_history.invoke(
    {"messages": [HumanMessage(content="whats my name?")], "language": "Spanish"},
    config=config,
)

response.content
```

```text
'Tu nombre es Bob.'
```

### Managing Conversation History

One important concept to understand when building chatbots is how to manage conversation history. If left unmanaged, the list of messages will grow unbounded and potentially overflow the context window of the LLM. Therefore, it is important to add a step that limits the size of the messages you are passing in. Use the `trim_messages` helper to manage the message list.

```python
from langchain_core.messages import SystemMessage, trim_messages
from operator import itemgetter
from langchain_core.runnables import RunnablePassthrough

trimmer = trim_messages(
    max_tokens=1024,
    strategy="last",
    token_counter=model,
    include_system=True,
    allow_partial=False,
    start_on="human",
)

chain = (
    RunnablePassthrough.assign(messages=itemgetter("messages") | trimmer)
    | prompt
    | model
)

with_message_history = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="messages",
)
```

Test the trimmed conversation:

```python
response = with_message_history.invoke(
    {
        "messages": messages + [HumanMessage(content="what's my name?")],
        "language": "English",
    },
    config=config,
)
```

### Conclusion

In this guide, we have covered the essential steps for building a simple chatbot using LangChain, including setting up a conversational model, maintaining message history, and managing conversation context. These foundational techniques will prepare you for more advanced chatbot development tasks.

# Task

1. Create a simple chatbot for writing and refining a user's movie review. The interaction between the user and the chatbot should be done over terminal (command prompt on Windows). Example conversation:

```plaintext
User: Please write a short template for a positive review of the movie Inception.

Assistant: Title: "Inception: A Mind-Bending Masterpiece"
Christopher Nolan's "Inception" is a cinematic tour de force that captivates audiences with its complex narrative, stunning visuals, and outstanding performances...

User: Can you make it shorter?

Assistant: Christopher Nolan's "Inception" is a masterpiece that captivates audiences with its complex narrative and stunning visuals.

User: Can you make it negative?

Assistant: Christopher Nolan's "Inception" is an overly complex and confusing film that fails to engage audiences. The convoluted narrative and excessive exposition bog down the pacing, making it a frustrating viewing experience.
```

2. The user should be able to terminate the program by typing `END`.

3. The user should also be able to switch between different conversations by typing `CONVERSATION <id>`, for example `CONVERSATION inception_review`.

4. Include the option to restart the current conversation (clear memory) and use the specified language for communication instead of English by typing `LANGUAGE <language_name>`, for example `LANGUAGE Croatian`.