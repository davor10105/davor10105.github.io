# Prompting Techniques

## Zero-shot Prompting

Large language models (LLMs) today, such as GPT-3.5 Turbo, GPT-4, and Claude 3, are tuned to follow instructions and are trained on large amounts of data. Large-scale training makes these models capable of performing some tasks in a "zero-shot" manner. Zero-shot prompting means that the prompt used to interact with the model won't contain examples or demonstrations. The zero-shot prompt directly instructs the model to perform a task without any additional examples to steer it.

Let's define a prompt for sentiment classification:

**Prompt:**
```text
Classify the text into neutral, negative or positive. 
Text: I think the vacation is okay.
Sentiment:
```

**Output:**
```text
Neutral
```

When zero-shot doesn't work, it's recommended to provide demonstrations or examples in the prompt which leads to few-shot prompting.

## Few-shot Prompting

While large-language models demonstrate remarkable zero-shot capabilities, they still fall short on more complex tasks when using the zero-shot setting. Few-shot prompting can be used as a technique to enable in-context learning where we provide demonstrations in the prompt to steer the model to better performance. The demonstrations serve as conditioning for subsequent examples where we would like the model to generate a response.

Example from a paper by [Brown et al.](https://arxiv.org/abs/2005.14165):

**Prompt**
```text
A "whatpu" is a small, furry animal native to Tanzania. An example of a sentence that uses the word whatpu is:
We were traveling in Africa and we saw these very cute whatpus.
 
To do a "farduddle" means to jump up and down really fast. An example of a sentence that uses the word farduddle is:
```

**Output**
```text
When we won the game, we all started to farduddle in celebration.
```

We can observe that the model has somehow learned how to perform the task by providing it with just one example (i.e., 1-shot). For more difficult tasks, we can experiment with increasing the demonstrations (e.g., 3-shot, 5-shot, 10-shot, etc.).

Here are a few more tips about demonstrations/exemplars when doing few-shot (proposed in this [paper](https://arxiv.org/abs/2202.12837)):

    - the label space and the distribution of the input text specified by the demonstrations are both important (regardless of whether the labels are correct for individual inputs!)"
    - the format you use also plays a key role in performance, even if you just use random labels, this is much better than no labels at all.
    - additional results show that selecting random labels from a true distribution of labels (instead of a uniform distribution) also helps.

Let's try out a few examples. Let's first try an example with random labels (meaning the labels Negative and Positive are randomly assigned to the inputs):

**Prompt:**
```text
This is awesome! // Negative
This is bad! // Positive
Wow that movie was rad! // Positive
What a horrible show! //
```

**Output:**
```text
Negative
```

We still get the correct answer, even though the labels have been randomized. Note that we also kept the format, which helps too.

Standard few-shot prompting works well for many tasks but is still not a perfect technique, especially when dealing with more complex reasoning tasks that require several reasoning steps. Recently, chain-of-thought (CoT) prompting has been popularized to address more complex arithmetic, commonsense, and symbolic reasoning tasks.

## Chain-of-Thought

Chain-of-Thought prompting essentially involves adding "Let's think step by step" to the original prompt. Let's try a simple problem and see how the model performs:

**Prompt:**
```text
I went to the market and bought 10 apples. I gave 2 apples to the neighbor and 2 to the repairman. I then went and bought 5 more apples and ate 1. How many apples did I remain with?
```

**Output:**
```text
11 apples
```

The answer is incorrect! Now Let's try with the special prompt.

**Prompt:**
```text
I went to the market and bought 10 apples. I gave 2 apples to the neighbor and 2 to the repairman. I then went and bought 5 more apples and ate 1. How many apples did I remain with?
```

Let's think step by step.

**Output:**
```text
First, you started with 10 apples.
You gave away 2 apples to the neighbor and 2 to the repairman, so you had 6 apples left.
Then you bought 5 more apples, so now you had 11 apples.
Finally, you ate 1 apple, so you would remain with 10 apples.
```

It's impressive that this simple prompt is effective at this task. This is particularly useful where you don't have too many examples to use in the prompt.

## Self-Consistency

Self-consistency aims to replace the naive greedy decoding used in chain-of-thought prompting. The idea is to sample multiple, diverse reasoning paths, and use the generations to select the most consistent answer.

Let's try the following example for arithmetic reasoning:

Prompt:

When I was 6 my sister was half my age. Now
I’m 70 how old is my sister?

Output:

35

The output is wrong! How may we improve this with self-consistency? Let's try it out. We will use several few-shot examples as well:

**Prompt:**
```text
Q: There are 15 trees in the grove. Grove workers will plant trees in the grove today. After they are done,
there will be 21 trees. How many trees did the grove workers plant today?
A: We start with 15 trees. Later we have 21 trees. The difference must be the number of trees they planted.
So, they must have planted 21 - 15 = 6 trees. The answer is 6.

Q: If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?
A: There are 3 cars in the parking lot already. 2 more arrive. Now there are 3 + 2 = 5 cars. The answer is 5.

Q: Leah had 32 chocolates and her sister had 42. If they ate 35, how many pieces do they have left in total?
A: Leah had 32 chocolates and Leah’s sister had 42. That means there were originally 32 + 42 = 74
chocolates. 35 have been eaten. So in total they still have 74 - 35 = 39 chocolates. The answer is 39.

Q: When I was 6 my sister was half my age. Now I’m 70 how old is my sister?
A:
```

**Output 1:**
```text
When I was 6 my sister was half my age, so she was 3. Now I am 70, so she is 70 - 3 = 67. The answer is 67.
```

**Output 2:**
```text
When the narrator was 6, his sister was half his age, which is 3. Now that the narrator is 70, his sister would be 70 - 3 = 67 years old. The answer is 67.
```

**Output 3:**
```text
When I was 6 my sister was half my age, so she was 3. Now I am 70, so she is 70/2 = 35. The answer is 35.
```

Computing for the final answer involves a few steps (check out the [paper](https://arxiv.org/abs/2203.11171) for the details) but for the sake of simplicity, we can see that there is already a majority answer emerging (67) so that would essentially become the final answer.

# Task
Read more about different prompting techniques in the following papers:

1. [Finetuned Language Models Are Zero-Shot Learners](https://arxiv.org/abs/2109.01652)
2. [Language Models are Few-Shot Learners](https://arxiv.org/abs/2005.14165)
3. [Chain-of-Thought Prompting Elicits Reasoning in Large Language Models](https://arxiv.org/abs/2201.11903)
4. [Self-Consistency Improves Chain of Thought Reasoning in Language Models](https://arxiv.org/abs/2203.11171)
5. [Generated Knowledge Prompting for Commonsense Reasoning](https://arxiv.org/abs/2110.08387)
6. [ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629)