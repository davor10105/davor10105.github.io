# Training your own "Large" Language Model from scratch

There are a couple of ways to train your own LLM from scratch. Most prominent ways are Masked Language Modeling (MLM) and Causal Language Modeling (CLM).

## Masked Language Modeling (MLM)

### Introduction

Masked Language Modeling (MLM) is a pivotal technique in natural language processing (NLP) that underlies many state-of-the-art models, including BERT (Bidirectional Encoder Representations from Transformers). MLM enables models to understand the context of words within sentences, making them highly effective for various NLP tasks.

### What is Masked Language Modeling?

Masked Language Modeling is a pre-training objective for language models where certain words in a sentence are masked (replaced with a special token), and the model learns to predict these masked words based on the surrounding context. This approach encourages the model to develop a deep understanding of the context and relationships between words.

![An illustration of masked language modeling objective](images/mlm.png)

### Key Features of MLM

1. **Contextual Understanding:** Forces the model to consider the context of words from both directions (left and right).
2. **Bidirectionality:** Unlike traditional left-to-right models, MLM allows the model to look at the entire sentence, leading to a more comprehensive understanding.
3. **Self-Supervision:** The training data can be generated from any text corpus without the need for labeled data.

## How Masked Language Modeling Works

### Step-by-Step Process

1. **Input Preparation:**
   - The input text is tokenized into individual tokens (words or subwords).
   - A certain percentage (usually 15%) of these tokens are selected to be masked.

2. **Masking Tokens:**
   - The selected tokens are replaced with a special `[MASK]` token. For example, in the sentence "The cat sat on the mat," if "sat" is chosen to be masked, it becomes "The cat [MASK] on the mat."

3. **Model Training:**
   - The model is trained to predict the original tokens that were masked, using the context provided by the unmasked tokens. In the example, the model should predict "sat" from "The cat [MASK] on the mat."
   - During training, the model uses bidirectional context, meaning it considers both the words before and after the masked token.

### Example:
- **Original Sentence:** "The quick brown fox jumps over the lazy dog."
- **Masked Sentence:** "The quick brown [MASK] jumps over the lazy dog."
- **Model's Task:** Predict that the masked word is "fox."

## Significance of Masked Language Modeling

### 1. Enhanced Contextual Understanding

MLM trains models to understand the context of a word from all directions, leading to a more nuanced representation of language compared to unidirectional models.

### 2. Pre-Training for Downstream Tasks

MLM serves as a pre-training objective, creating a foundation that can be fine-tuned for various downstream NLP tasks like text classification, named entity recognition (NER), and question answering.

### 3. Improved Performance

Models pre-trained with MLM, such as BERT, have achieved state-of-the-art performance on many NLP benchmarks due to their deep contextual understanding.

Certainly! Here's a comprehensive educational piece on causal language modeling:

---

## Causal Language Modeling (CLM)

### Introduction

Causal Language Modeling (CLM) is a foundational technique in natural language processing (NLP) where a model learns to predict the next token in a sequence based solely on the previous tokens. This autoregressive approach forms the basis of many prominent language models, such as GPT (Generative Pre-trained Transformer).

### What is Causal Language Modeling?

Causal Language Modeling is an approach where the model generates text by predicting the next token in a sequence, using only the tokens that precede it. This type of modeling is essential for tasks that require text generation, such as writing assistance, dialogue systems, and more.

![An illustration of the causal language modeling objective](images/clm.png)

### Key Features of CLM

1. **Autoregression:** Generates text one token at a time, conditioning each prediction on all previously generated tokens.
2. **Unidirectional Context:** Only uses past context, not future tokens, for making predictions.
3. **Self-Supervised Learning:** Can be trained on large amounts of text without labeled data.

## How Causal Language Modeling Works

### Step-by-Step Process

1. **Input Preparation:**
   - The input text is tokenized into a sequence of tokens (words or subwords).

2. **Autoregressive Prediction:**
   - The model is trained to predict the next token in the sequence, given the previous tokens. For example, given the input sequence "The cat sat on the," the model should predict "mat."

3. **Training Objective:**
   - The objective is to maximize the likelihood of the correct next token, which is achieved by minimizing the cross-entropy loss between the predicted token probabilities and the actual tokens.

### Example:
- **Input Sequence:** "The quick brown fox"
- **Next Token Prediction:** Given the input, the model should predict "jumps."

## Significance of Causal Language Modeling

### 1. Natural Language Generation

CLM is crucial for generating human-like text in a coherent and contextually relevant manner. By predicting one token at a time, the model can produce fluent and logical text sequences.

### 2. Scalability and Adaptability

Since CLM uses self-supervised learning, it can be trained on vast amounts of text data, allowing the model to learn a wide range of language patterns and styles.

### 3. Foundation for Advanced Models

Many advanced NLP models, such as GPT and its variants, rely on CLM for their foundational architecture. These models have demonstrated state-of-the-art performance in various language generation tasks.

## How Causal Language Modeling Differs from Masked Language Modeling

### 1. Context Utilization

- **CLM:** Uses only the preceding tokens to predict the next token, making it unidirectional.
- **MLM:** Can use both preceding and succeeding tokens to predict masked tokens, making it bidirectional.

### 2. Training Objective

- **CLM:** Trains to predict the next token in a sequence, enhancing its text generation capabilities.
- **MLM:** Trains to predict randomly masked tokens within a sequence, improving its understanding of context and bidirectional relationships.

# Task

1. Implement training scripts for training your own "large" language models from scratch using the huggingface `transformers` library. Check out the following tutorials for [MLM](https://huggingface.co/learn/nlp-course/en/chapter7/3?fw=pt) and [CLM](https://huggingface.co/learn/nlp-course/en/chapter7/6).
- Use the first 2500 examples from each category of the sentiment classification dataset used in the previous task (only the textual part) as your training corpus (5000 examples total).
- For the MLM implementation, use the [bert-tiny model](https://huggingface.co/prajjwal1/bert-tiny)
- For the CLM implementation, use the [tiny-gpt2 model](https://huggingface.co/sshleifer/tiny-gpt2)

2. Use the `text-generation` pipeline to generate text from the following sequence for both of the trained models:

```text
My favourite fruits are:
```

[Next Page](10_open_closed_source_llms.md)

