## Vector Stores

Vector stores, also known as vector databases or embedding databases, are specialized databases designed to store, manage, and query vectorized data. The primary purpose of vector stores is to facilitate efficient similarity searches, making them crucial for applications involving large-scale data retrieval and analysis.

Traditional databases are not optimized for the complexity and dimensionality of vector data. Vector stores address this gap by providing specialized indexing and querying mechanisms that support fast and accurate similarity searches, crucial for applications like recommendation systems, image recognition, and natural language processing.

### Key Features

#### High-Dimensional Data Handling

Vector stores are optimized for handling high-dimensional data, often involving hundreds or thousands of dimensions. They use specialized indexing techniques such as Approximate Nearest Neighbor (ANN) search to manage and query this data efficiently.

#### Scalability

Designed to handle large-scale data, vector stores can manage millions or even billions of vectors. They provide scalable architectures that can be distributed across multiple nodes, ensuring high availability and fault tolerance.

#### Real-Time Querying

Vector stores support real-time querying capabilities, allowing for fast retrieval of similar vectors. This is essential for applications requiring quick responses, such as online recommendation systems and real-time analytics.

#### Integration with Machine Learning Workflows

These databases integrate seamlessly with machine learning pipelines, enabling easy storage and retrieval of model-generated embeddings. This facilitates the development and deployment of AI-powered applications.

### Architecture of Vector Stores

#### Indexing Techniques

Vector stores employ various indexing techniques to efficiently manage and search high-dimensional vector data. Some common techniques include:

- **Approximate Nearest Neighbor (ANN) Search**: Reduces search time by approximating the nearest neighbors rather than computing exact distances.
- **Hierarchical Navigable Small World (HNSW)**: Constructs a graph-based index that allows for efficient and scalable nearest neighbor searches.
- **Product Quantization (PQ)**: Compresses vectors into smaller representations to reduce memory usage and speed up search times.

#### Data Storage

Vectors are typically stored in a highly optimized format that allows for fast read and write operations. Some vector stores use in-memory storage for faster access, while others may use disk-based storage with efficient caching mechanisms.

#### Query Engine

The query engine is responsible for processing search queries and retrieving the most similar vectors. It leverages the indexing structures to perform fast similarity searches, often using metrics like cosine similarity, Euclidean distance, or Manhattan distance.

### Types of Vector Stores

#### Standalone Vector Stores

Standalone vector stores are dedicated databases designed specifically for vector data. Examples include:
- **Faiss**: Developed by Facebook AI Research, Faiss is a library for efficient similarity search and clustering of dense vectors.
- **ChromaDB**: AI-native open-source vector database. Chroma makes it easy to build LLM apps by making knowledge, facts, and skills pluggable for LLMs.

#### Integrated Vector Stores

Integrated vector stores are built into broader database systems or cloud services, providing vector storage and search capabilities alongside traditional database features. Examples include:
- **Elasticsearch**: With plugins and extensions, Elasticsearch can handle vector data and perform similarity searches.
- **AWS OpenSearch**: An Amazon service that offers vector search capabilities integrated with the OpenSearch suite.

### ChromaDB Semantic Search Example

```bash
pip install chromadb
```

```python
import chromadb
chroma_client = chromadb.Client()

# switch `create_collection` to `get_or_create_collection` to avoid creating a new collection every time
collection = chroma_client.get_or_create_collection(name="my_collection")

# switch `add` to `upsert` to avoid adding the same documents every time
collection.add(
    documents=[
        "This is a document about pineapple",
        "This is a document about oranges"
    ],
    metadatas = [{"source": "newspapers"}, {"source": "online"}],
    ids=["id1", "id2"]
)

results = collection.query(
    query_texts=["This is a query document about florida"], # Chroma will embed this for you
    n_results=2 # how many results to return
)

print(results)
```

The documents can also be filtered using any passed metadata fields by using the `where` keyword:

```python
results = collection.query(
    query_texts=["This is a query document"],
    n_results=2,
    where={"metadata_field": "is_equal_to_this"}
)
```

### OpenSearch

OpenSearch vector store can easily be constructed and queried using LangChain:

```bash
pip install opensearch-py langchain-community
```

```python
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import OpenSearchVectorSearch
from langchain_community.embeddings import BedrockEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import TextLoader

# Instantiate Embeddings object
embeddings = BedrockEmbeddings(...)

# Load data
loader = TextLoader("test_corpus.txt")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(documents)

# Create the vector store
docsearch = OpenSearchVectorSearch.from_documents(
    docs, embeddings, opensearch_url="http://localhost:9200"
)

# Query the vector store
query = "What did the president say about Ketanji Brown Jackson"
docs = docsearch.similarity_search(query, k=10)
```


### Task
1. Create a local vector store using ChromaDB and populate it with 200 random examples from the IMDB dataset. Make sure to use the "positive" and "negative" labels as metadata in the store. Use the Amazon Titan model from the previous chapter as an embedding function. Use the [custom embeddings](https://docs.trychroma.com/guides/embeddings) in ChromaDB, specifically [AmazonBedrockEmbeddingFunction](https://github.com/chroma-core/chroma/blob/main/chromadb/utils/embedding_functions.py#L811).
2. Find 5 most similar reviews in the "positive" category and 5 most similar reviews in the "negative" category compared to the following text: "action movie".

[Next Page](5_embedding_task.md)