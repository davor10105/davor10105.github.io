# Transformer: A Detailed Explanation

The Transformer model, introduced by Vaswani et al. in 2017, has revolutionized natural language processing (NLP) and is the foundation for many state-of-the-art models like BERT and GPT. Unlike traditional models that process text sequentially, the Transformer uses a parallelizable architecture that allows it to handle long-range dependencies more effectively.

## 1. Transformer Architecture Overview

The Transformer architecture is composed of an encoder and a decoder. Each consists of a stack of identical layers. The encoder processes the input text, and the decoder generates the output text.

![An illustration of the transformer archtecture](images/transformer.png)

### Encoder-Decoder Structure

- **Encoder:** Converts the input text into a sequence of continuous representations.
- **Decoder:** Converts these representations into the desired output text.

Each encoder and decoder layer is composed of two main sub-layers: a multi-head self-attention mechanism and a position-wise fully connected feed-forward network. The decoder has an additional sub-layer that performs multi-head attention over the encoder’s output.

## 2. Encoder Structure

The encoder consists of \(N\) identical layers. Each layer has two sub-layers:

1. **Multi-Head Self-Attention Mechanism**
2. **Position-Wise Fully Connected Feed-Forward Network**

### Multi-Head Self-Attention Mechanism

The self-attention mechanism allows the model to weigh the importance of different words in a sentence relative to each other. This is achieved through the following steps:

#### 2.1.1 Input Embedding and Positional Encoding

- **Input Embedding:** Converts words into continuous vector representations.
- **Positional Encoding:** Adds information about the position of each word in the sentence because the Transformer lacks the sequential nature of RNNs. The positional encoding is added to the input embeddings.

#### 2.1.2 Computing Attention Scores

For each word in the input sequence, the attention mechanism computes three vectors: Query ($Q$), Key ($K$), and Value ($V$). These vectors are computed as follows:
$$Q = XW^Q, \quad K = XW^K, \quad V = XW^V $$
where $X$ is the input matrix, and $W^Q$, $W^K$, and $W^V$ are learned weight matrices.

The attention scores are computed using the scaled dot-product attention:
$$\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V $$
where $d_k$ is the dimensionality of the key vectors.

#### 2.1.3 Multi-Head Attention

Instead of performing a single attention function, the Transformer uses multi-head attention to allow the model to jointly attend to information from different representation subspaces at different positions. This is done by running several attention mechanisms in parallel and concatenating their outputs:
$$\text{MultiHead}(Q, K, V) = \text{Concat}(\text{head}_1, \ldots, \text{head}_h)W^O$$
where each head $i$ is computed as:
$$\text{head}_i = \text{Attention}(QW_i^Q, KW_i^K, VW_i^V)$$

### Position-Wise Fully Connected Feed-Forward Network

Each attention output is passed through a feed-forward network, which consists of two linear transformations with a ReLU activation in between:
$$\text{FFN}(x) = \max(0, xW_1 + b_1)W_2 + b_2$$

### Layer Normalization and Residual Connections

To stabilize training, each sub-layer (attention and feed-forward) in the encoder employs layer normalization and residual connections:
$$\text{LayerNorm}(x + \text{Sublayer}(x))$$

## 3. Decoder Structure

The decoder also consists of $N$ identical layers, each with three sub-layers:

1. **Masked Multi-Head Self-Attention Mechanism**
2. **Multi-Head Attention Mechanism (over the encoder's output)**
3. **Position-Wise Fully Connected Feed-Forward Network**

### Masked Multi-Head Self-Attention Mechanism

The masked self-attention mechanism ensures that the predictions for a particular word can depend only on the known outputs before that word. This is achieved by masking out (setting to -∞) all subsequent positions.

### Multi-Head Attention Over Encoder Output

The second sub-layer in each decoder layer performs multi-head attention over the encoder's output, allowing the decoder to focus on relevant parts of the input sequence.

### Position-Wise Fully Connected Feed-Forward Network

Similar to the encoder, each decoder layer includes a feed-forward network applied to the attention outputs.

### Layer Normalization and Residual Connections

As with the encoder, each sub-layer in the decoder employs layer normalization and residual connections.

## 4. Final Linear and Softmax Layer

After passing through all the decoder layers, the decoder output is transformed by a final linear layer and a softmax layer to produce the probabilities for the next word in the sequence:
$$\text{Probabilities} = \text{softmax}(W \cdot \text{DecoderOutput})$$

## 5. Training the Transformer

The Transformer is trained using a large corpus of text, where it learns to predict the next word in a sequence. The training involves minimizing the cross-entropy loss between the predicted and actual words.

[Next Page](8_tokenizers.md)