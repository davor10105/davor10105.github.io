# Deploying Your Own Large Language Models (LLMs)

Deploying your own Large Language Models (LLMs) can offer significant advantages in terms of customization, control, and security. While pre-trained models provided by third-party services are powerful and convenient, hosting your own LLMs can better meet specific needs and use cases. This guide will explore why deploying your own LLMs is useful, the steps involved, and the associated security implications.

### **Why Deploy Your Own LLMs?**

#### **Customization**

1. **Tailored Training Data**:
   - Deploying your own LLM allows you to train or fine-tune the model on domain-specific data, resulting in more accurate and relevant outputs for your particular use case.

2. **Specialized Use Cases**:
   - Custom models can be optimized for niche applications, such as specific industry jargon, regulatory requirements, or unique organizational processes.

#### **Control**

1. **Operational Flexibility**:
   - Hosting your own LLMs provides full control over the infrastructure and the ability to optimize performance, scale as needed, and integrate with existing systems seamlessly.

2. **Data Governance**:
   - You maintain complete control over your data, ensuring compliance with data protection regulations and organizational policies.

#### **Security**

1. **Enhanced Privacy**:
   - By deploying LLMs on-premises or in a private cloud, you can mitigate risks associated with sending sensitive data to external services.

2. **Access Control**:
   - Custom deployments allow for stringent access controls and security measures tailored to your specific security requirements.

### **Steps to Deploy Your Own LLMs**

There are many ways to deploy your own LLM - AWS SageMaker, Vertex AI, Together AI etc. However, one of the most versatile and generic ways is using a combination of vLLM and SkyPilot.

**vLLM** is a fast and easy-to-use library for LLM inference and serving.

vLLM is fast with:
- State-of-the-art serving throughput
- Efficient management of attention key and value memory with PagedAttention
- Continuous batching of incoming requests
- Quantization: GPTQ, AWQ, SqueezeLLM, FP8 KV Cache (lower memory requirements)
- Optimized CUDA kernels

**SkyPilot** is a framework for running LLMs, AI, and batch jobs on any cloud, offering maximum cost savings, highest GPU availability, and managed execution.

SkyPilot abstracts away cloud infrastructure burdens:
- Launch jobs & clusters on any cloud
- Easy scale-out: queue and run many jobs, automatically managed
- Easy access to object stores (S3, GCS, R2)

SkyPilot cuts cloud costs:
- Managed Spot: 3-6x cost savings using spot VMs, with auto-recovery from preemptions
- Optimizer: 2x cost savings by auto-picking the cheapest VM/zone/region/cloud
- Autostop: hands-free cleanup of idle clusters

Current supported providers: AWS, GCP, Azure, OCI, Lambda Cloud, RunPod, Fluidstack, Cudo, IBM, Samsung, Cloudflare, VMware vSphere, any Kubernetes cluster.

### Installation

Install both libraries using `pip` (choose SkyPilot cloud provider based on your needs):

```bash
pip install vllm

pip install "skypilot-nightly[aws]"
pip install "skypilot-nightly[gcp]"
pip install "skypilot-nightly[azure]"
pip install "skypilot-nightly[oci]"
pip install "skypilot-nightly[lambda]"
pip install "skypilot-nightly[runpod]"
pip install "skypilot-nightly[fluidstack]"
pip install "skypilot-nightly[paperspace]"
pip install "skypilot-nightly[cudo]"
pip install "skypilot-nightly[ibm]"
pip install "skypilot-nightly[scp]"
pip install "skypilot-nightly[vsphere]"
pip install "skypilot-nightly[kubernetes]"
pip install "skypilot-nightly[all]"
```

After installation, run `sky check` to verify that credentials are correctly set up:

```bash
sky check
```

This will produce a summary like:

```bash
Checking credentials to enable clouds for SkyPilot.
  AWS: enabled
  GCP: enabled
  Azure: enabled
  OCI: enabled
  Lambda: enabled
  RunPod: enabled
  Paperspace: enabled
  Fluidstack: enabled
  Cudo: enabled
  IBM: enabled
  SCP: enabled
  vSphere: enabled
  Cloudflare (for R2 object store): enabled
  Kubernetes: enabled
```

SkyPilot will use only the enabled clouds to run tasks. To change this, configure cloud credentials, and run sky check.
If any cloud’s credentials or dependencies are missing, sky check will output hints on how to resolve them. You can also refer to the [cloud setup section](https://skypilot.readthedocs.io/en/latest/getting-started/installation.html#cloud-account-setup).

### Model Deployment

1. Choose any model from the [HuggingFace model hub](https://huggingface.co/models). Here, we use [this](https://huggingface.co/TheBloke/NeuralHermes-2.5-Mistral-7B-GPTQ) model.

2. Check the required GPU memory for your chosen model [here](https://huggingface.co/docs/accelerate/v0.30.0/en/usage_guides/model_size_estimator).

3. Find the appropriate instance for your model size ([AWS GPU Instances](https://docs.aws.amazon.com/dlami/latest/devguide/gpu.html)). Here we require a smaller instance with 24GB of VRAM (g5.xlarge for 1$ per hour on demand price).

Define a YAML file (`serving.yaml`) for SkyPilot that defines resources needed:

```yaml
resources:
  cloud: aws  # one of AWS, Azure, GCP, OCI, Lambda Cloud, RunPod, Fluidstack, Cudo, IBM, Samsung, Cloudflare, any Kubernetes cluster
  region: us-east-1  # your aws region
  instance_type: g5.xlarge  # cheapest instance large enough for the model
  ports: 8000  # port to expose (needed to query the model)

envs:
    MODEL_NAME: TheBloke/NeuralHermes-2.5-Mistral-7B-GPTQ  # model name from huggingface
    MODEL_REVISION: gptq-8bit-32g-actorder_True  # specific model file

# install requirements
setup: |
    conda create -n vllm python=3.9 -y
    conda activate vllm
    pip install vllm 

# run vllm server
run: |
    conda activate vllm
    echo 'Starting vllm api server...'
    python -m vllm.entrypoints.openai.api_server \
                    --model $MODEL_NAME \
                    --tensor-parallel-size $SKYPILOT_NUM_GPUS_PER_NODE \
                    --revision $MODEL_REVISION \
                    --dtype auto 2>&1 | tee api_server.log &
```

Finally, start your instance under the name `mistral_serve`:

```bash
sky launch -c mistral_serve serving.yaml
```

Now you can retrieve the endpoint IP:

```bash
sky status mistral_serve --endpoint 8000
```

And use the model via LangChain:

```python
from langchain_community.llms import VLLMOpenAI

llm = VLLMOpenAI(
    openai_api_key="EMPTY",
    openai_api_base=<endpoint_ip>,
    model_name="TheBloke/NeuralHermes-2.5-Mistral-7B-GPTQ",
)
print(llm.invoke("Rome is"))
```